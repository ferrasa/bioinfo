#!/usr/bin/env python3
"""Explora e valida grupos RNA-Seq do NCBI e gera META/samples.tsv.

Aceita SraRunTable.csv exportado pelo Run Selector e o formato SraRunInfo.csv.
Uso para esta aula:
  python3 scripts/00_metadados.py --csv META/SraRunTable.csv \
    --control shoot_Watered_Day1 --treated shoot_Drought_Day1
"""
import argparse
import csv
import re
import sys
from collections import defaultdict
from pathlib import Path

parser = argparse.ArgumentParser(description='Selecionar 3 controles + 3 tratados de um CSV do NCBI')
parser.add_argument('--csv', default='META/SraRunTable.csv', help='CSV do NCBI (Run Selector ou RunInfo)')
parser.add_argument('--list', action='store_true', help='Listar grupos com pelo menos 3 réplicas')
parser.add_argument('--control', help='Nome exato do grupo controle')
parser.add_argument('--treated', help='Nome exato do grupo tratado')
parser.add_argument('--max-mb', type=float, default=200, help='Máximo em MB decimais por run')
parser.add_argument('--out', default='META/samples.tsv', help='Caminho da matriz de amostras')
args = parser.parse_args()

with open(args.csv, newline='', encoding='utf-8-sig') as f:
    data = list(csv.DictReader(f))
if not data or 'Run' not in data[0]:
    sys.exit('ERRO: CSV de metadados vazio ou sem a coluna Run')


def field(r, *names):
    """Nomes de colunas variam entre SraRunTable e SraRunInfo."""
    for name in names:
        value = r.get(name, '')
        if value is not None and str(value).strip():
            return str(value).strip()
    return ''


def classify(r):
    name = field(r, 'Library Name', 'LibraryName', 'Sample Name', 'SampleName')
    match = re.match(r'^(.*?)[_ .-]+(?:rep|replicate)[_ .-]*([1-9][0-9]*)$', name, flags=re.I)
    if not match:
        return None
    if field(r, 'LibraryLayout').upper() != 'SINGLE':
        return None
    if field(r, 'Assay Type', 'LibraryStrategy').upper() != 'RNA-SEQ':
        return None
    if 'arabidopsis' not in field(r, 'Organism', 'ScientificName').lower():
        return None
    try:
        if field(r, 'Bytes'):
            size_mb = int(field(r, 'Bytes')) / 1e6
        else:
            size_mb = float(field(r, 'size_MB'))
    except (ValueError, TypeError):
        return None
    if size_mb > args.max_mb:
        return None
    return match.group(1), int(match.group(2)), size_mb


groups = defaultdict(list)
for r in data:
    result = classify(r)
    if result:
        group, replicate, size_mb = result
        groups[group].append((replicate, r['Run'], size_mb, r))

if args.list or not (args.control and args.treated):
    print(f'Grupos RNA-Seq SINGLE de Arabidopsis (SRA <= {args.max_mb} MB por run):')
    for group, records in sorted(groups.items()):
        by_rep = defaultdict(list)
        for rep, run, mb, _ in records:
            by_rep[rep].append((run, mb))
        if len(by_rep) >= 3:
            print(f'\nGRUPO: {group} | réplicas distintas: {len(by_rep)}')
            for rep in sorted(by_rep):
                print('  rep%d  %s' % (rep, ', '.join(f'{run} ({mb:.1f} MB)' for run, mb in by_rep[rep])))
    if not (args.control and args.treated):
        sys.exit(0)

if args.control == args.treated:
    sys.exit('ERRO: grupos controle e tratamento não podem ser idênticos')

selected = []
for condition, group in [('controle', args.control), ('tratamento', args.treated)]:
    if group not in groups:
        sys.exit(f'ERRO: grupo {group!r} não encontrado. Execute --list')
    by_rep = defaultdict(list)
    for rep, run, mb, raw in groups[group]:
        by_rep[rep].append((run, mb, raw))
    if set(by_rep) != {1, 2, 3}:
        sys.exit(f'ERRO: {group!r} requer réplicas 1, 2, 3; encontradas {sorted(by_rep)}')
    for rep in (1, 2, 3):
        if len(by_rep[rep]) != 1:
            sys.exit(f'ERRO: {group} rep{rep} tem {len(by_rep[rep])} runs; confira réplicas técnicas')
        run, mb, raw = by_rep[rep][0]
        selected.append((run, condition, rep, raw))

if len({x[0] for x in selected}) != 6:
    sys.exit('ERRO: há acesso SRR repetido na seleção')

# Compara potenciais fatores de confusão disponíveis no CSV.
for cols in [('tissue',), ('Ecotype',), ('dev_stage',), ('Instrument',), ('BioProject',)]:
    values = {field(row, *cols) for _, _, _, row in selected if field(row, *cols)}
    if len(values) > 1:
        sys.exit(f'ERRO: metadado {cols[0]} é incompatível entre amostras: {sorted(values)}')

Path(args.out).parent.mkdir(parents=True, exist_ok=True)
with open(args.out, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f, delimiter='\t', lineterminator='\n')
    writer.writerow(['run', 'condition', 'replicate'])
    writer.writerows((run, condition, rep) for run, condition, rep, _ in selected)
print(f'Arquivo gravado: {args.out}')
for run, condition, rep, _ in selected:
    print(f'{run}\t{condition}\t{rep}')
