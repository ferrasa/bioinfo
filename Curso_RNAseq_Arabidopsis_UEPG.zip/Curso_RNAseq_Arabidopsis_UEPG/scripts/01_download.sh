#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p FASTQ SRA TMP LOGS
[[ -s META/samples.tsv ]] || { echo 'Primeiro gere META/samples.tsv'; exit 1; }
# Uma amostra por vez evita picos de espaço ao converter SRA->FASTQ.
while IFS=$'\t' read -r run cond rep; do
  [[ "$run" == run ]] && continue
  [[ "$run" =~ ^SRR[0-9]+$ ]] || { echo "Run inválido: $run"; exit 1; }
  [[ -f "FASTQ/${run}.fastq.gz" ]] && { echo "FASTQ já existe: $run"; continue; }
  echo "[DOWNLOAD] $run ($cond, rep$rep)"
  prefetch "$run" --max-size 250M --output-directory "$PWD/SRA" 2>&1 | tee "LOGS/${run}_prefetch.log"
  fasterq-dump "$PWD/SRA/$run" --threads 2 --outdir "$PWD/FASTQ" --temp "$PWD/TMP" 2>&1 | tee "LOGS/${run}_fasterq.log"
  [[ -s "FASTQ/${run}.fastq" ]] || { echo "ERRO: arquivo FASTQ/${run}.fastq ausente (confira se é single-end)."; exit 1; }
  gzip -1 "FASTQ/${run}.fastq"
  gzip -t "FASTQ/${run}.fastq.gz"
  # Remova SRA depois da conversão bem-sucedida para poupar espaço.
  rm -rf -- "SRA/$run"
done < META/samples.tsv
du -sh FASTQ
