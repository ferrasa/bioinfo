#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p REF/STAR LOGS
BASE='https://ftp.ensemblgenomes.ebi.ac.uk/pub/plants/release-63'
FASTA='Arabidopsis_thaliana.TAIR10.dna.toplevel.fa'
GTF='Arabidopsis_thaliana.TAIR10.63.gtf'
for name in "$FASTA" "$GTF"; do
  if [[ ! -s "REF/$name" ]]; then
    if [[ "$name" == "$FASTA" ]]; then
      url="$BASE/fasta/arabidopsis_thaliana/dna/${name}.gz"
    else
      url="$BASE/gtf/arabidopsis_thaliana/${name}.gz"
    fi
    curl -fL --retry 3 -o "REF/${name}.gz" "$url"
    gunzip -f "REF/${name}.gz"
  fi
done
[[ -s "REF/$FASTA" && -s "REF/$GTF" ]] || exit 1
# Ajuste da indexação para genoma pequeno (~135 Mb). -sparseD 2 reduz RAM/índice.
STAR --runMode genomeGenerate \
     --runThreadN "${THREADS:-2}" \
     --genomeDir "$PWD/REF/STAR" \
     --genomeFastaFiles "$PWD/REF/$FASTA" \
     --sjdbGTFfile "$PWD/REF/$GTF" \
     --sjdbOverhang 99 \
     --genomeSAindexNbases 12 \
     --genomeSAsparseD 2 2>&1 | tee LOGS/genomeGenerate.log
