#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p QC/FASTQC LOGS
fastqc -t "${THREADS:-2}" -o QC/FASTQC FASTQ/*.fastq.gz 2>&1 | tee LOGS/fastqc.log
if command -v multiqc >/dev/null 2>&1; then
  multiqc QC/FASTQC -o QC -f 2>&1 | tee LOGS/multiqc.log
fi
