#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p BAM TMP LOGS
[[ -s REF/STAR/Genome ]] || { echo 'Índice STAR ausente. Execute 02_referencia.sh'; exit 1; }
while IFS=$'\t' read -r run cond rep; do
  [[ "$run" == run ]] && continue
  [[ -s "FASTQ/${run}.fastq.gz" ]] || { echo "FASTQ ausente: $run"; exit 1; }
  [[ -s "BAM/${run}.bam" ]] && { echo "BAM já existe: $run"; continue; }
  echo "[STAR] $run"
  STAR --runThreadN "${THREADS:-2}" \
       --genomeDir "$PWD/REF/STAR" \
       --readFilesIn "$PWD/FASTQ/${run}.fastq.gz" \
       --readFilesCommand zcat \
       --outFileNamePrefix "$PWD/BAM/${run}_" \
       --outSAMtype BAM SortedByCoordinate \
       --limitBAMsortRAM 1000000000 \
       --outTmpDir "$PWD/TMP/STAR_${run}" 2>&1 | tee "LOGS/${run}_STAR.log"
  mv "BAM/${run}_Aligned.sortedByCoord.out.bam" "BAM/${run}.bam"
  samtools index -@ "${THREADS:-2}" "BAM/${run}.bam"
  [[ -e "TMP/STAR_${run}" ]] && rm -rf -- "TMP/STAR_${run}"
done < META/samples.tsv
