#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p COUNT LOGS
bams=()
while IFS=$'\t' read -r run cond rep; do
  [[ "$run" == run ]] && continue
  [[ -s "BAM/${run}.bam" ]] || { echo "BAM ausente: $run"; exit 1; }
  bams+=("BAM/${run}.bam")
done < META/samples.tsv
[[ ${#bams[@]} -eq 6 ]] || { echo 'São exigidas 6 amostras'; exit 1; }
# O conjunto selecionado é SINGLE-end. Contamos exons agregados por gene_id.
# O protocolo de biblioteca deve ser conferido para decidir -s (0 = unstranded).
featureCounts -T "${THREADS:-2}" -s "${STRAND:-0}" -t exon -g gene_id \
  -a REF/Arabidopsis_thaliana.TAIR10.63.gtf \
  -o COUNT/featureCounts.txt "${bams[@]}" 2>&1 | tee LOGS/featureCounts.log
python3 scripts/make_matrix.py
