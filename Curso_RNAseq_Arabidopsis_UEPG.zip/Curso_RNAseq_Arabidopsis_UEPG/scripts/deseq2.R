#!/usr/bin/env Rscript
# DESeq2 didático. Recebe metadados explícitos (não presume ordem de colunas).
suppressPackageStartupMessages(library(DESeq2))
a <- commandArgs(trailingOnly = TRUE)
if (length(a) != 3) stop('Uso: Rscript deseq2.R META/samples.tsv COUNT/count_matrix.tsv DGE')
metadata <- read.delim(a[1], check.names = FALSE, stringsAsFactors = FALSE)
count_df <- read.delim(a[2], check.names = FALSE, stringsAsFactors = FALSE)
outdir <- a[3]
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)
stopifnot(all(c('run', 'condition', 'replicate') %in% colnames(metadata)))
stopifnot(identical(sort(metadata$condition), sort(rep(c('controle','tratamento'), each=3))))
stopifnot(!anyDuplicated(metadata$run), !anyDuplicated(count_df$gene_id))
stopifnot(setequal(metadata$run, colnames(count_df)[-1]))
rownames(count_df) <- count_df$gene_id
count_df$gene_id <- NULL
# A ordem de colunas é determinada por run, não por posição no arquivo.
counts <- as.matrix(count_df[, metadata$run, drop=FALSE])
if (anyNA(counts) || any(counts < 0) || any(counts != round(counts)))
    stop('Contagens devem ser inteiros não-negativos, sem NA')
storage.mode(counts) <- 'integer'
rownames(metadata) <- metadata$run
metadata$condition <- factor(metadata$condition, levels=c('controle','tratamento'))
write.table(metadata, file=file.path(outdir,'samples_used.tsv'), sep='\t', quote=FALSE, row.names=FALSE)
write.table(data.frame(run=colnames(counts), total_reads=colSums(counts)),
            file=file.path(outdir,'library_sizes.tsv'),sep='\t',quote=FALSE,row.names=FALSE)

# O DESeq2 modela a variância dos counts brutos; NUNCA use FPKM/TPM como entrada.
dds <- DESeqDataSetFromMatrix(countData=counts, colData=metadata, design=~condition)
# Pré-filtro: ao menos 10 counts em ao menos 3 amostras (didático; ajustável).
keep <- rowSums(counts(dds) >= 10) >= 3
dds <- dds[keep,]
if (nrow(dds) == 0L) stop('Nenhum gene após o pré-filtro.')
dds <- DESeq(dds)
res <- results(dds, contrast=c('condition','tratamento','controle'), alpha=0.05)
res_df <- as.data.frame(res)
res_df$gene_id <- rownames(res_df)
res_df <- res_df[order(res_df$padj, na.last=TRUE), c('gene_id',setdiff(colnames(res_df),'gene_id'))]
write.table(res_df,file=file.path(outdir,'DGE_all.tsv'), sep='\t', quote=FALSE,row.names=FALSE)
sig <- subset(res_df, !is.na(padj) & padj < 0.05 & abs(log2FoldChange) >= 1)
write.table(sig,file=file.path(outdir,'DGE_significant.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
norm <- counts(dds, normalized=TRUE)
write.table(data.frame(gene_id=rownames(norm),norm,check.names=FALSE),
            file=file.path(outdir,'normalized_counts.tsv'),sep='\t',quote=FALSE,row.names=FALSE)

png(file.path(outdir,'dispersion.png'), width=1000,height=850,res=120)
plotDispEsts(dds)
dev.off()
png(file.path(outdir,'MA.png'), width=1000,height=850,res=120)
plotMA(res,ylim=c(-3,3))
dev.off()
png(file.path(outdir,'pvalues.png'),width=1000,height=850,res=120)
hist(res$pvalue[is.finite(res$pvalue)], breaks=40,main='Distribuição dos p-values',xlab='p-value')
dev.off()

# VST é mais leve do que rlog e apropriado para PCA/agrupamento.
vsd <- varianceStabilizingTransformation(dds,blind=FALSE)
pca <- prcomp(t(assay(vsd)))
percent <- round(100*pca$sdev^2/sum(pca$sdev^2),1)
cols <- ifelse(metadata$condition == 'controle', '#2463a6', '#cd7045')
png(file.path(outdir,'PCA.png'),width=1000,height=850,res=120)
plot(pca$x[,1],pca$x[,2],col=cols,pch=19,cex=1.7,
     xlab=paste0('PC1 (',percent[1],'%)'),ylab=paste0('PC2 (',percent[2],'%)'),
     main='PCA das amostras (VST)')
text(pca$x[,1],pca$x[,2],labels=rownames(pca$x),pos=3,cex=.7)
legend('topright',legend=c('controle','tratamento'),col=c('#2463a6','#cd7045'),pch=19,bty='n')
dev.off()
sampleDists <- as.matrix(dist(t(assay(vsd))))
png(file.path(outdir,'sample_distances.png'),width=1000,height=850,res=120)
heatmap(sampleDists,Rowv=NA,Colv=NA,symm=TRUE,margins=c(10,10),main='Distâncias entre amostras')
dev.off()

png(file.path(outdir,'volcano.png'),width=1000,height=850,res=120)
x <- res$log2FoldChange
y <- -log10(pmax(res$padj,.Machine$double.xmin))
good <- is.finite(x) & is.finite(y)
plot(x[good],y[good],pch=20,cex=.6,col=ifelse(res$padj[good]<.05 & abs(x[good])>=1,'tomato3','grey60'),
     xlab='log2 fold change (tratamento / controle)', ylab='-log10(padj)', main='Volcano plot')
abline(v=c(-1,1),lty=2,col='grey45'); abline(h=-log10(.05),lty=2,col='grey45')
dev.off()

sink(file.path(outdir,'summary.txt'))
cat('Comparação: tratamento vs controle\n')
cat('Genes antes do filtro:',nrow(counts),'\n')
cat('Genes após o filtro:',nrow(dds),'\n')
cat('Genes com padj < 0.05 e abs(log2FC) >= 1:',nrow(sig),'\n')
cat('Regulação para cima no tratamento:',sum(sig$log2FoldChange>0),'\n')
cat('Regulação para baixo no tratamento:',sum(sig$log2FoldChange<0),'\n\n')
print(summary(res))
cat('\n\nSessão R:\n');print(sessionInfo())
sink()
message('Concluído: ', outdir)
