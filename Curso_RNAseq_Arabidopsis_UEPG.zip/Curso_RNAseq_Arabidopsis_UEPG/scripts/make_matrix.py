#!/usr/bin/env python3
"""Converte featureCounts full output em matriz sem índices de coluna fixos."""
import csv
from pathlib import Path

with open('META/samples.tsv', newline='') as f:
    samples = list(csv.DictReader(f, delimiter='\t'))
with open('COUNT/featureCounts.txt', newline='') as f:
    table = csv.reader((line for line in f if not line.startswith('#')), delimiter='\t')
    header = next(table)
    if header[:6] != ['Geneid','Chr','Start','End','Strand','Length']:
        raise SystemExit(f'Formato inesperado de featureCounts: {header[:6]!r}')
    runs = [Path(s).stem for s in header[6:]]
    target = [s['run'] for s in samples]
    if sorted(runs) != sorted(target):
        raise SystemExit(f'ERRO: colunas BAM {runs} não coincidem com amostras {target}')
    ids = [runs.index(s) + 6 for s in target]
    with open('COUNT/count_matrix.tsv', 'w', newline='') as g:
        out = csv.writer(g, delimiter='\t', lineterminator='\n')
        out.writerow(['gene_id'] + target)
        for row in table:
            if len(row) != len(header):
                raise SystemExit('Coluna ausente em featureCounts; arquivo inválido')
            out.writerow([row[0]] + [row[i] for i in ids])
print('COUNT/count_matrix.tsv criada com', len(target), 'amostras.')
