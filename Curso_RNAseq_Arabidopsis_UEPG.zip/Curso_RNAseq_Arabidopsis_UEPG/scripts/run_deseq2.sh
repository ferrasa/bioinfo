#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p DGE LOGS
Rscript scripts/deseq2.R META/samples.tsv COUNT/count_matrix.tsv DGE 2>&1 | tee LOGS/deseq2.log
